from django.apps import AppConfig


class CommentstoreappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'commentstoreapp'
