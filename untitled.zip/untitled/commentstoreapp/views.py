# Importing necessary modules
from django.shortcuts import render, redirect



# Sign Up Page
def register_choice(request):
    """
    View function to render the registration choice page.
    """
    return render(request, 'register/register_choice.html')
